# Advanced Event Registration App

Run `npm install` then `npm run dev`.